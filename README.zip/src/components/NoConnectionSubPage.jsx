export default function NoConnectionSubPage({}) {
  return (
    <div className="bg-red-700 absolute top-0 left-0 h-[1200px] w-[1920px]">
      <h1 className="text-7xl text-white">NO CONNECTION TO PROCESSOR</h1>
    </div>
  );
}
